﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;
using System.Timers;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Utilities;

namespace Project
{
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    /// 


    public class InboxClass : INotifyPropertyChanged
    {
        private string _inbox;

        public string Inbox
        {
            get
            {
                return _inbox;
            }
            set
            {
                _inbox = value;
                OnPropertyChanged();
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string caller = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));
            }
        }

        public static InboxClass GetContent()
        {
            var emp = new InboxClass()
            {
                Inbox = "Inbox"
            };
            return emp;
        }
    }
    public partial class Menu : Window
    {


        private InboxClass _inbox_component;
        private static int ok_frame = 0;
        private static string Date = "29/10/2021";
        private static int InboxCnt = 0;
        private static List<string> lista;


        
        public void threadFunction(Object source,ElapsedEventArgs e)
        {
            
            string currrentTime = DateTime.Now.ToString("dd/MM/yyyy");


            if ((string)Date == currrentTime)
            {
                //MessageBox.Show(currrentTime);
                //set in database
            }

            
        }


       

        public Menu()
        {

            InitializeComponent();
            this.Title = "Airline Reservation System";
            MainFrame.Content = new BlankPage();


            _inbox_component = new InboxClass
            {
                Inbox = "Inbox"
            };

            System.Timers.Timer timer = new System.Timers.Timer(1000);
            timer.Elapsed += threadFunction;
            timer.AutoReset = true;
            timer.Enabled = true;

            DataContext = _inbox_component;
            _inbox_component.Inbox = InboxCnt.ToString();
        }


        private void New_Flight(object sender, RoutedEventArgs e)
        {
            if(MainWindow.flights==null)
            {
                MainWindow.flights = new Flights();
                
            }
            MainWindow.flights.Left = this.Left;
            MainWindow.flights.Top = this.Top;
            MainWindow.flights.Show();
            this.Hide();
        }

        private void View_Flights(object sender, RoutedEventArgs e)
        {
            if (ok_frame == 0)
            {
                ok_frame = 1;
            }
            MainFrame.Content = new ViewFlights();

        }

        private void Privacy(object sender, RoutedEventArgs e)
        {
            if(MainWindow.privacy == null)
            {
                MainWindow.privacy = new Privacy();
            }

            MainWindow.privacy.Left = this.Left;
            MainWindow.privacy.Top = this.Top;
            MainWindow.privacy.Show();
            this.Hide();

        }

        private void My_Profile(object sender, RoutedEventArgs e)
        {
            if (ok_frame == 0)
            {
                ok_frame = 1;
            }
            MainFrame.Content = new MyProfile();

        }

        private void About(object sender, RoutedEventArgs e)
        {

            if (ok_frame == 0)
            {
                ok_frame = 1;
            }
            MainFrame.Content = new About();
            //MainFrame.Navigate(new Uri("About.xaml", UriKind.Relative));
        }

        private void Log_Out(object sender, RoutedEventArgs e)
        {
            Client.ClientID = 0;                             //re-init clientID

            if (MainWindow.flights != null)
            {
                MainWindow.flights.Close();
                MainWindow.flights = null;
            }

            MainWindow.login.Left = this.Left;
            MainWindow.login.Top = this.Top;
            MainWindow.login.Show();

            MainWindow.menu.Close();
            MainWindow.menu = null;

        }

        private void MainFrame_MouseLeave(object sender, MouseEventArgs e)
        {
            MainFrameLeave();
        }


        private void MainFrameLeave()
        {
            while (MainFrame.NavigationService.CanGoBack == true)
            {
                MainFrame.NavigationService.GoBack();
                MainFrame.NavigationService.RemoveBackEntry();
            }
            ok_frame = 0;
        }

        private void MenuBackground_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MainFrameLeave();
        }
    }
}
