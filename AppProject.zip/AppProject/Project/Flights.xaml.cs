﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for Flights.xaml
    /// </summary>
    /// 

    public partial class Flights : Window
    {
        private List<string> list;
        public Flights()
        {
            InitializeComponent();
            this.Title = "Airline Reservation System";
            DestinationView.Visibility = Visibility.Hidden;
            DepartureView.Visibility = Visibility.Hidden;
            DepartureCalendar.Visibility = Visibility.Hidden;
            DestinationCalendar.Visibility = Visibility.Hidden;


            DestinationCalendar.BlackoutDates.Add(new CalendarDateRange(DateTime.Parse("01/01/1970"), DateTime.Today));
            DepartureCalendar.BlackoutDates.Add(new CalendarDateRange(DateTime.Parse("01/01/1970"), DateTime.Today));

            list = new List<string>();
            list.Add("Londra");
            list.Add("Madrid");
            list.Add("Monaco");
            list.Add("Tanzania");
            list.Add("Lisabona");
            list.Add("Liasi");

        }



        //LostFocus  --   momentul in care click ul mouse ului a fost focusat
        //                          pe alt element din interfata  

        //GotFocus   --   Click-ul pe un element din interfata(doar la primul click raspunde)

        //MouseMove  --   trigger cand mouseul atinge suprafata elementului din interfata

        //MouseLeave --   trigger cand mouseul paraseste suprafata elementului din interfata

        //KeyDown   -- trigger la apasare de tasta

        //------------------------------------------------------------------------------------------


        //Destination events


        //label destination events
        private void DestinationLabel_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DestinationView == null || DestinationView.SelectedItems.Count > 0 || DestinationLabel.Text == "Destination")
            {
                return;
            }
            DestinationView.Items.Clear();

            List<string> listWithElement = Client.GetDestinationsResponse();
            if (listWithElement[0] == Utilities.Utility._DESTINATION_FAILED)
            {
                MessageBox.Show("Destination Failed!");
                return;
            }

            listWithElement.Remove(listWithElement.First());
            listWithElement = listWithElement.Distinct().ToList();
            
            foreach (string item in listWithElement)
            {
                string temp = DestinationLabel.Text.ToString();
                if (temp != "")
                {
                    if (item.ToLower().StartsWith(temp.ToLower()) || item.Substring(item.IndexOf(',')+1).ToLower().StartsWith(temp.ToLower()))
                    {
                        DestinationView.Items.Add(item);
                    }
                }
                else
                    DestinationView.Items.Add(item);
            }

        }
        private void DestinationLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            DestinationView.Visibility = Visibility.Hidden;
            if (DestinationLabel.Text.Length == 0 && DestinationView.SelectedItems.Count <= 0)
                DestinationLabel.Text = "Destination";
        }

        private void Destination_GotFocus(object sender, RoutedEventArgs e)
        {
            DestinationLabel.Clear();
            DestinationView.Visibility = Visibility.Visible;
        }

        private void DestinationLabel_KeyDown(object sender, KeyEventArgs e)
        {
            DestinationView.Visibility = Visibility.Visible;
            ListViewItem lvi = DestinationView.ItemContainerGenerator.ContainerFromIndex(0) as ListViewItem;
        }

        //ListView destination events
        private void DestinationView_MouseLeave(object sender, MouseEventArgs e)
        {
            DestinationView.Visibility = Visibility.Hidden;
        }

        private void DestinationView_Selected(object sender, RoutedEventArgs e)
        {
            if (DestinationView.SelectedItems.Count == 1)
            {
                DestinationLabel.Text = DestinationView.SelectedItem.ToString();
                FlightResponseAction();
                FlightTwoWayResponseAction();
                DestinationView.Items.Clear();
                DestinationView.Visibility = Visibility.Hidden;
            }
        }





        //Calendar Destination events

        private void CalendarDest_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            DestinationCalendar.Visibility = Visibility.Visible;
            DepartureCalendar.Visibility = Visibility.Hidden;
        }

        private void DestinationCalendar_MouseMove(object sender, MouseEventArgs e)
        {
            DestinationCalendar.Visibility = Visibility.Visible;
        }

        private void DestinationCalendar_MouseLeave(object sender, MouseEventArgs e)
        {
            DestinationCalendar.Visibility = Visibility.Hidden;
            //DestinationCalendar.SelectedDates.Clear();
        }
        private void DestinationCalendar_LostFocus(object sender, RoutedEventArgs e)
        {
            DestinationCalendar.Visibility = Visibility.Hidden;
        }




        //---------------------------------------------------------------------------------------------------
        //Desparture events

        private void DepartureLabel_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DepartureView == null || DepartureView.SelectedItems.Count > 0 || DepartureLabel.Text == "Departure")
            {
                return;
            }
            DepartureView.Items.Clear();

            List<string> listWithElement = Client.GetDepartureResponse();
            if (listWithElement[0] == Utilities.Utility._DEPARTURE_FAILED)
            {
                MessageBox.Show("Destination Failed!");
                return;
            }

            listWithElement.Remove(listWithElement.First());
            listWithElement = listWithElement.Distinct().ToList();

            foreach (string item in listWithElement)
            {
                string temp = DepartureLabel.Text;
                if (temp != "")
                {
                    if (item.ToLower().StartsWith(temp.ToLower()) || item.Substring(item.IndexOf(',') + 1).ToLower().StartsWith(temp.ToLower()))
                    {
                        DepartureView.Items.Add(item);
                    }
                }
                else
                    DepartureView.Items.Add(item);
            }
        }
        private void Departure_GotFocus(object sender, RoutedEventArgs e)
        {
            DepartureLabel.Clear();
            DepartureView.Visibility = Visibility.Visible;
        }
        private void DepartureLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            DepartureView.Visibility = Visibility.Hidden;
            if (DepartureLabel.Text.Length == 0)
                DepartureLabel.Text = "Departure";
        }

        private void DepartureLabel_OnKeyDown(object sender, KeyEventArgs e)
        {
            DepartureLabel.Visibility = Visibility.Visible;
            if (e.Key == Key.Down)
            {
                //DepartureView.SelectedItem = DepartureView.Items[0];
                //DepartureView.ScrollIntoView(DepartureView.SelectedItem);

                //ListViewItem lvi = (ListViewItem)DepartureView.ItemContainerGenerator.ContainerFromIndex(DepartureView.SelectedIndex);
                //lvi.Focus();
            }
        }




        //ListView departure events


        private void DepartureView_MouseLeave(object sender, MouseEventArgs e)
        {
            DepartureView.Visibility = Visibility.Hidden;
        }


        private void DepartureView_Selected(object sender, RoutedEventArgs e)
        {
            if (DepartureView.SelectedItems.Count == 1)
            {
                DepartureLabel.Text = DepartureView.SelectedItem.ToString();
                FlightResponseAction();
                FlightTwoWayResponseAction();
                DepartureView.Items.Clear();
                DepartureView.Visibility = Visibility.Hidden;
            }
        }


        //Calendar events
        private void Calendar_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            DepartureCalendar.Visibility = Visibility.Visible;
            DestinationCalendar.Visibility = Visibility.Hidden;
        }
        private void DepartureCalendar_MouseMove(object sender, MouseEventArgs e)
        {
            DepartureCalendar.Visibility = Visibility.Visible;
        }

        private void DepartureCalendar_MouseLeave(object sender, MouseEventArgs e)
        {
            DepartureCalendar.Visibility = Visibility.Hidden;
        }







        private void BookFlightButton_Click(object sender, RoutedEventArgs e)
        {
            if (TwoWayLabel.IsChecked == false)
            {
                string iDate = DestinationCalendar.SelectedDate.ToString();
                DateTime oDate = Convert.ToDateTime(iDate);
                Utilities.Message mess = Client.GetBookFlightResponse(DestinationLabel.Text, DepartureLabel.Text, oDate.ToString("yyyy-M-d"));

                if (mess.GetRequest().ToString() == Utilities.Utility._BOOK_FLIGHT_SUCCESS)
                {

                    MessageBox.Show("You have successfully booked your flight!");
                    MainWindow.menu.Left = this.Left;
                    MainWindow.menu.Top = this.Top;
                    MainWindow.menu.Show();
                    this.Hide();
                    PriceLabel.Text = "Price: ";
                    TicketsLabel.Text = "Tickets: ";
                    DestinationLabel.Text = "Destination";
                    DepartureLabel.Text = "Departure";
                    DestinationCalendar.SelectedDates.Clear();
                    DepartureCalendar.SelectedDates.Clear();
                }
                else
                {
                    MessageBox.Show("Something went wrong...");
                }
            }
            else
            {
                //2 way ticket
                string data_dus= DestinationCalendar.SelectedDate.ToString();
                DateTime oDate = Convert.ToDateTime(data_dus);

                string data_intoarcere = DepartureCalendar.SelectedDate.ToString();
                DateTime oDate2 = Convert.ToDateTime(data_intoarcere);

                Utilities.Message mess = Client.GetBook2WayFlightResponse(DestinationLabel.Text, DepartureLabel.Text, oDate.ToString("yyyy-M-d"), oDate2.ToString("yyyy-M-d"));

                if (mess.GetRequest().ToString() == Utilities.Utility._BOOK_2WAY_FLIGHT_SUCCESS)
                {
                    MessageBox.Show("You have successfully booked your flight!");
                    MainWindow.menu.Left = this.Left;
                    MainWindow.menu.Top = this.Top;
                    MainWindow.menu.Show();
                    this.Hide();
                    PriceLabel.Text = "Price: ";
                    TicketsLabel.Text = "Tickets: ";
                    DestinationLabel.Text = "Destination";
                    DepartureLabel.Text = "Departure";
                    DestinationCalendar.SelectedDates.Clear();
                    DepartureCalendar.SelectedDates.Clear();
                }

            }
        
        }

        private void BackToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.menu.Left = this.Left;
            MainWindow.menu.Top = this.Top;
            MainWindow.menu.Show();
            this.Hide();
        }

        //in momentul in care vreau sa inchid toate elementele din interfata
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DestinationView.Visibility = Visibility.Hidden;
            DepartureView.Visibility = Visibility.Hidden;
            DepartureCalendar.Visibility = Visibility.Hidden;
            DestinationCalendar.Visibility = Visibility.Hidden;

            //sterge focus ul atat la nivel fizic de tastatura cat si la nivel logic
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(DestinationLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(DepartureLabel), null);
            Keyboard.ClearFocus();
        }

        private void Image_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {

        }

        private void TwoWayLabel_Checked(object sender, RoutedEventArgs e)
        {
            CalendarIcon.Visibility = Visibility.Visible;
            DepartureCalendar.SelectedDates.Clear();
        }

        private void TwoWayLabel_Unchecked(object sender, RoutedEventArgs e)
        {
            CalendarIcon.Visibility = Visibility.Hidden;
            DepartureCalendar.SelectedDates.Clear();
        }

        private void DestinationCalendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            for (var index = 1; index < DepartureCalendar.BlackoutDates.Count; index++)
                DepartureCalendar.BlackoutDates.RemoveAt(index);
            if(DestinationCalendar.SelectedDates.Count>0)
                DepartureCalendar.BlackoutDates.Add(new CalendarDateRange(DateTime.Now, DestinationCalendar.SelectedDate.Value));
            FlightResponseAction();
            FlightTwoWayResponseAction();
        }

        private void FlightResponseAction()
        {
            if (DestinationLabel.Text.Length.Equals(0) || DepartureLabel.Text.Length.Equals(0) || (!DestinationCalendar.SelectedDate.HasValue))
                return;
            string iDate = DestinationCalendar.SelectedDate.ToString();
            DateTime oDate = Convert.ToDateTime(iDate);
            List<string> list = Client.GetAvailableFlightResponse(DestinationLabel.Text, DepartureLabel.Text, oDate.ToString("yyyy-M-d"));

            if (list.First().Equals(Utilities.Utility._AVAILABLE_FLIGHT_FAILED))
            {
                BookFlightButton.Visibility = Visibility.Hidden;
                PriceLabel.Text = "Price: ";
                TicketsLabel.Text = "Tickets: ";
            }
            else
            {
                TicketsLabel.Text = $"Tickets: {list[1]}";
                PriceLabel.Text = $"Price: {list[2]}";

                if (TwoWayLabel.IsChecked == false)
                {
                    if (Int32.Parse(list[1]) == 0)
                    {
                        BookFlightButton.Visibility = Visibility.Hidden;
                    }
                    else
                    {
                        BookFlightButton.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void FlightTwoWayResponseAction()
        {
            if (TwoWayLabel.IsChecked == false)
                return;
            if (DepartureLabel.Text.Length.Equals(0) || DestinationLabel.Text.Length.Equals(0) || (!DepartureCalendar.SelectedDate.HasValue) || (!DepartureCalendar.SelectedDate.HasValue))
                return;
            string iDate = DepartureCalendar.SelectedDate.ToString();
            DateTime oDate = Convert.ToDateTime(iDate);
            List<string> list = Client.GetAvailableFlightResponse(DepartureLabel.Text, DestinationLabel.Text, oDate.ToString("yyyy-M-d"));

            if (list.First().Equals(Utilities.Utility._AVAILABLE_FLIGHT_FAILED))
            {
                BookFlightButton.Visibility = Visibility.Hidden;
                PriceLabel.Text = "Price: ";
                TicketsLabel.Text = "Tickets: ";
            }
            else
            {
                int tickete_dus = 0;
                string[] fragmente = TicketsLabel.Text.ToString().Split(' ');
                if(fragmente[1].Length > 0)
                {
                     tickete_dus = Int32.Parse(fragmente[1]);             
                }
                 
                if (tickete_dus > Int32.Parse(list[1]))
                    TicketsLabel.Text = $"Tickets: {list[1]}";
                int result = 0;
                if (PriceLabel.Text != "Price: ")
                {
                    result = Int32.Parse(PriceLabel.Text.ToString().Split(' ')[1]) + Int32.Parse(list[2]);
                    PriceLabel.Text = $"Price: {result}";
                }

                
                if (Int32.Parse(list[1]) == 0 || tickete_dus == 0)
                {
                    BookFlightButton.Visibility = Visibility.Hidden;
                }
                else
                {
                    BookFlightButton.Visibility = Visibility.Visible;
                }

            }
        }

        private void DepartureCalendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            for (var index = 1; index < DestinationCalendar.BlackoutDates.Count; index++)
                DestinationCalendar.BlackoutDates.RemoveAt(index);
            if (DepartureCalendar.SelectedDates.Count > 0)
                DestinationCalendar.BlackoutDates.Add(new CalendarDateRange(DepartureCalendar.SelectedDate.Value, DateTime.MaxValue));

            FlightResponseAction();
            FlightTwoWayResponseAction();
        }
    }
}

