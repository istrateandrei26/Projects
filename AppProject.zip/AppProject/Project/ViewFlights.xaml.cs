﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for ViewFlights.xaml
    /// </summary>
    public partial class ViewFlights : Page
    {
        public ViewFlights()
        {
            InitializeComponent();
            List<string> ListWithPastFlights = Client.GetPastFlightsResponse();
            if (ListWithPastFlights[0] == Utilities.Utility._PAST_FLIGHTS_FAILED)
            {
                PastFlightsContent.Items.Add("No past flights yet.");
            }
            else
            {
                ListWithPastFlights.Remove(ListWithPastFlights.First());


                foreach (var item in ListWithPastFlights)
                {
                    PastFlightsContent.Items.Add(item);
                }

            }
            List<string> ListWithFutureFlights=Client.GetFutureFlightsResponse();
            if (ListWithFutureFlights[0] == Utilities.Utility._FUTURE_FLIGHTS_FAILED)
            {
                FutureFlightsContent.Items.Add("No future flights yet.");
            }
            else
            {
                ListWithFutureFlights.Remove(ListWithFutureFlights.First());


                foreach (var item in ListWithFutureFlights)
                {
                    FutureFlightsContent.Items.Add(item);
                }
                
            }
        }
    }
}
