﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for Privacy.xaml
    /// </summary>
    public partial class Privacy : Window
    {
        public Privacy()
        {
            InitializeComponent();
            this.Title = "Airline Reservation System";
        }

        private void ChangePassButton_Click(object sender, RoutedEventArgs e)
        {
            //
            //

            if (NewPasswodLabel.Text != ConfirmNewPassLabel.Text)
            {
                MessageBox.Show("Confirm password does not match!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                int response = Client.GetChangePasswordResponse(OldPasswordLabel.Text,NewPasswodLabel.Text);
                if (response == Int32.Parse(Utilities.Utility._CHANGE_PASS_SUCCESS))
                {
                    if (MessageBox.Show("Successfully changed password!", "Notification", MessageBoxButton.OK, MessageBoxImage.Information) == MessageBoxResult.OK)
                    {
                        this.Hide();
                        MainWindow.menu.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Old password does not match!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void BackToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow.menu.Show();
        }

        private void OldPasswordLabel_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
