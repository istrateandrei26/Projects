﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for register.xaml
    /// </summary>

    public partial class register : Window
    {
        public register()
        {
            InitializeComponent();
            this.Title = "Airline Reservation System";
            for(int i=18;i<=100;i++)
            {
                AgeComboBox.Items.Add(i.ToString());
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            MainWindow.login.Left = this.Left;
            MainWindow.login.Top = this.Top;
            MainWindow.login.Show();

            this.Hide();
        }

        private void Message(object sender, RoutedEventArgs e)
        {

            //facem verificari la campuri
            Regex findDigits = new Regex(@"[0-9]");
            if (findDigits.IsMatch(FirstNameLabel.Text))
            {
                MessageBox.Show("First Name should not contain digits");
                return;
            }
            if (findDigits.IsMatch(LastNameLabel.Text))
            {
                MessageBox.Show("Last Name should not contain digits");
                return;
            }

            Regex validateEmail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");   //
            if (!validateEmail.IsMatch(EmailLabel.Text))
            {
                MessageBox.Show("Invalid Email address");
                return;
            }

            Regex validateCnp = new Regex(@"[^0-9]");
            if(validateCnp.IsMatch(CNPLabel.Text) || CNPLabel.Text.Length != 13)
            {
                MessageBox.Show("Invalid CNP");
                return;
            }



            if (FirstNameLabel.Text.Length==0  || 
               LastNameLabel.Text.Length==0   ||
               EmailLabel.Text.Length==0      ||
               CNPLabel.Text.Length==0        ||
               PasswordLabel.Password.Length==0   ||
               UsernameLabel.Text.Length==0   ||
               PasswordLabel.Password != ConfPasswordLabel.Password)
                MessageBox.Show("Please complete all fields !");
            else
            {
                //MessageBox.Show("Succsessful");
                int return_code = Client.GetRegisterResponse(FirstNameLabel.Text, LastNameLabel.Text, EmailLabel.Text, CNPLabel.Text, AgeComboBox.SelectedItem.ToString(), UsernameLabel.Text, PasswordLabel.Password);
                if (return_code.ToString() != Utilities.Utility._REGISTER_SUCCES)
                    MessageBox.Show("Register failed");
                else
                {
                    UsernameLabel.Text="Username";
                    FirstNameLabel.Text="First Name";
                    LastNameLabel.Text="Last Name";
                    CNPLabel.Text="CNP";
                    EmailLabel.Text="Email";
                    PasswordLabel.Clear();
                    ConfPasswordLabel.Clear();

                    MainWindow.login.Left = this.Left;
                    MainWindow.login.Top = this.Top;
                    MainWindow.login.Show();

                    this.Hide();
                    MessageBox.Show("Successfully registered !");
                }
            }
        }

        private void FirstNameLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            FirstNameLabel.Clear();
        }

        private void LastNameLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            LastNameLabel.Clear();
        }

        private void CNPLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            CNPLabel.Clear();
        }

        private void EmailLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            EmailLabel.Clear();
        }

        private void UsernameLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            UsernameLabel.Clear();
        }

        private void PasswordLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordLabel.Clear();
        }

        private void ConfPasswordLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            ConfPasswordLabel.Clear();
        }

        private void FirstNameLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if(FirstNameLabel.Text.Length == 0)
            {
                FirstNameLabel.Text = "First Name";
            }
        }

        private void LastNameLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if (LastNameLabel.Text.Length == 0)
            {
                LastNameLabel.Text = "Last Name";
            }
        }

        private void CNPLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if (CNPLabel.Text.Length == 0)
            {
                CNPLabel.Text = "CNP";
            }
        }

        private void EmailLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if (EmailLabel.Text.Length == 0)
            {
                EmailLabel.Text = "Email";
            }
        }

        private void UsernameLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if (UsernameLabel.Text.Length == 0)
            {
                UsernameLabel.Text = "Username";
            }
        }

        private void PasswordLabel_LostFocus(object sender, RoutedEventArgs e)
        {
           
        }

        private void ConfPasswordLabel_LostFocus(object sender, RoutedEventArgs e)
        {
           
        }

        private void BackgroundRegisterImg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(UsernameLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(PasswordLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(ConfPasswordLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(FirstNameLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(LastNameLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(CNPLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(EmailLabel), null);
            Keyboard.ClearFocus();
        }
    }
}
