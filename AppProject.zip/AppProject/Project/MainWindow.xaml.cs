﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public class TimeHelper : INotifyPropertyChanged
    {
        private string current_time;

        public string CurrentTime
        {
            get
            {
                return current_time;
            }
            set
            {
                current_time = value;
                OnPropertyChanged();
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string caller = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));
            }
        }

        public static TimeHelper GetContent()
        {
            var emp = new TimeHelper()
            {
                current_time = DateTime.Now.ToString("HH mm ss")
            };
            return emp;
        }
    }
    public partial class MainWindow : Window
    {
        public static Window login=null;
        public static Window register=null;
        public static Window menu = null;
        public static Window flights = null;
        public static Window privacy = null;
        public static TimeHelper our_timer = TimeHelper.GetContent();

        Client client = null;
       
        public MainWindow()
        {
            
            InitializeComponent();
            this.Title = "Airline Reservation System";

            DataContext = our_timer;
            System.Timers.Timer timer = new System.Timers.Timer(1000);
            timer.Elapsed += UpdateTimer;
            timer.AutoReset = true;
            timer.Enabled = true;

            login = this;
            client = Client.getInstance();   //init client
            PasswordLabelPass.Password = "";
        }

        private void UpdateTimer(Object source, ElapsedEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                if (DateTime.Now.Second % 2 == 0)
                {
                    our_timer.CurrentTime = DateTime.Now.ToString("HH mm ss");
                    FirstDots.Foreground = Brushes.White;
                    SecondDots.Foreground = Brushes.White;
                    
                }

                else
                {
                    our_timer.CurrentTime = DateTime.Now.ToString("HH mm ss");
                    FirstDots.Foreground = Brushes.Black;
                    SecondDots.Foreground = Brushes.Black;
                }
            });
            
        }

        
        private void Register(object sender, RoutedEventArgs e)
        {
            if (register == null)
            {
                register = new register();
                
            }
            register.Left = this.Left;
            register.Top = this.Top;

            register.Show();
            this.Hide();


        }

        private void Menu(object sender, RoutedEventArgs e)
        {
            if(PasswordLabelPass.Password=="")
            {
                MessageBox.Show("Please complete password label !");
                return;
            }

            List<int> response_list = Client.GetLoginResponse(UsernameLabel.Text, PasswordLabelPass.Password);
            
            if (response_list[0].ToString() == Utilities.Utility._LOGIN_SUCCES)
            {
                Client.Password = PasswordLabelPass.Password;
                Client.ClientID = response_list[1];

                if (menu == null)
                {
                    menu = new Menu();

                }
                menu.Left = this.Left;
                menu.Top = this.Top;

                menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong credentials", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void UsernameLabel_GotFocus(object sender, RoutedEventArgs e)
        {
            UsernameLabel.Clear();
        }

        private void PasswordLabelPass_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordLabelPass.Clear();
        }

        private void UsernameLabel_LostFocus(object sender, RoutedEventArgs e)
        {
            if(UsernameLabel.Text.Length == 0)
            {
                UsernameLabel.Text = "Username";
            }
        }

        private void PasswordLabelPass_LostFocus(object sender, RoutedEventArgs e)
        {
            if(PasswordLabelPass.Password == "")
                PasswordLabelText.Visibility = Visibility.Visible;
        }

        private void BackgroundImgStart_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(UsernameLabel), null);
            FocusManager.SetFocusedElement(FocusManager.GetFocusScope(PasswordLabelPass), null);
            Keyboard.ClearFocus();
        }

        private void PasswordLabelText_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PasswordLabelText.Visibility = Visibility.Hidden;
        }
    }
}
