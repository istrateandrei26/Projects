﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Threading;
using System.Net.Sockets;
using Utilities;

namespace Project
{
    public sealed class Client
    {
        private static TcpClient client;
        private static StreamReader reader;
        private static StreamWriter writer;

        private static int clientID;
        private static string password;


        private static Client instance = null;
        public static Client getInstance()
        {
            if (instance == null)
                instance = new Client();


            return instance;
        }

        public static string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public static int ClientID
        {
            get
            {
                return clientID;
            }

            set
            {
                clientID = value;
            }
        }

        ~Client()
        {
            //reader.Close();
            //writer.Close();
            //client.Close();
        }
        public static int GetRegisterResponse(string FirstName, string LastName, string email, string cnp, string age, string username, string paswword)
        {
           
            Message message = new Message(Int32.Parse(Utility._REGISTER_REQUEST));
            message.Add(FirstName);
            message.Add(LastName);
            message.Add(email);
            message.Add(cnp);
            message.Add(age); // implicit
            message.Add(username);
            message.Add(paswword);
            message.AddEndOfMessage();
            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            

            return Int32.Parse(response);

        }

        public static List<int> GetLoginResponse(string username, string password)
        {
            Message message = new Message(Int32.Parse(Utility._LOGIN_REQUEST));
            message.Add(username);
            message.Add(password);
            message.AddEndOfMessage();

            writer.WriteLine(message.GetTheMessage());
            writer.Flush();

            string response = reader.ReadLine();

            Message from_server = new Message(response);
            List<string> elems = from_server.GetElementsOfMessage();
            List<int> result_response = new List<int>();
            if (elems.Count() == 2)
            {
                result_response.Add(Int32.Parse(elems[0]));
                result_response.Add(Int32.Parse(elems[1]));
            }
            else
            {
                result_response.Add(Int32.Parse(elems[0]));
            }


            return result_response;

        }

        public static int GetChangePasswordResponse(string oldPassword,string newPassword)
        {

            Message message = new Message(Int32.Parse(Utility._CHANGE_PASS_REQUEST));
            message.Add(clientID.ToString());
            message.Add(newPassword);
            message.Add(oldPassword);
            message.AddEndOfMessage();
            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();



            return Int32.Parse(response);

        }

          
        public static Message GetViewMyProfileResponse()
        {
            Message message = new Message(Int32.Parse(Utility._VIEW_PROFILE_REQUEST));
            message.Add(clientID.ToString());
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();



            return new Message(response);
        }
        
        public static List<string> GetDestinationsResponse()
        {
            Message message = new Message(Int32.Parse(Utility._DESTINATION_REQUEST));
      

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);
            List<string> list = mess.GetElementsOfMessage();
            return list;
        }
        public static List<string> GetDepartureResponse()
        {
            Message message = new Message(Int32.Parse(Utility._DEPARTURE_REQUEST));


            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);
            List<string> list = mess.GetElementsOfMessage();
            return list;
        }
        public static List<string> GetAvailableFlightResponse(string destination,string departure,string data)
        {
            Message message = new Message(Int32.Parse(Utility._AVAILABLE_FLIGHT_REQUEST));
            message.Add(destination);
            message.Add(departure);
            message.Add(data);
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);
            List<string> list = mess.GetElementsOfMessage();
            return list;
        }

        public static Message GetBookFlightResponse(string destination, string departure, string data)
        {
            Message message = new Message(Int32.Parse(Utility._BOOK_FLIGHT_REQUEST));
            message.Add(destination);
            message.Add(departure);
            message.Add(data);
            message.Add(Client.ClientID.ToString());
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);
            
            return mess;

        }

        public static Message GetBook2WayFlightResponse(string destination, string departure, string data_dus, string data_intoarcere)
        {
            Message message = new Message(Int32.Parse(Utility._BOOK_2WAY_FLIGHT_REQUEST));
            message.Add(destination);
            message.Add(departure);
            message.Add(data_dus);
            message.Add(data_intoarcere);
            message.Add(Client.ClientID.ToString());
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);

            return mess;
        }
        public static List<string> GetFutureFlightsResponse()
        {
            Message message = new Message(Int32.Parse(Utility._FUTURE_FLIGHTS_REQUEST));
            message.Add(Client.ClientID.ToString());
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);

            List<string> list = mess.GetElementsOfMessage();
            return list;
        }

        public static List<string> GetPastFlightsResponse()
        {
            Message message = new Message(Int32.Parse(Utility._PAST_FLIGHTS_REQUEST));
            message.Add(Client.ClientID.ToString());
            message.AddEndOfMessage();

            string m = message.GetTheMessage();
            writer.WriteLine(message.GetTheMessage());
            writer.Flush();


            string response = reader.ReadLine();

            Message mess = new Message(response);

            List<string> list = mess.GetElementsOfMessage();
            return list;
        }

        private Client()
        {
            clientID = 0;
            try
            {
                client = new TcpClient("127.0.0.1", 1080);
                reader = new StreamReader(client.GetStream());
                writer = new StreamWriter(client.GetStream());

                String s = String.Empty;
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        
    }
}
