﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Utilities;

namespace Project
{
    /// <summary>
    /// Interaction logic for MyProfile.xaml
    /// </summary>
    public partial class MyProfile : Page
    {
        public MyProfile()
        {
            InitializeComponent();

            Message response = Client.GetViewMyProfileResponse();
            List<string> details = response.GetElementsOfMessage();
            if (details.First() == Utility._VIEW_PROFILE_SUCCESS)
            {
                details.Remove(details.First());

                string LastName = details[0];
                string FirstName = details[1];
                string CNP = details[2];
                string Email = details[3];
                string username = details[4];

                LastNameLabel.Text = LastName.Trim();
                FirstNameLabel.Text = FirstName.Trim();
                CNPLabel.Text = CNP.Trim();
                EmailLabel.Text = Email.Trim();
                UsernameLabel.Text = username.Trim();
                VisibilePasswordLabel.Text = Client.Password;
                HiddenPasswordLabel.Password = Client.Password;
            }
        }

        private void PassImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (PassImage.Source.ToString().Split('/').Last() == "eye_hidden.png".ToString())
            {
                PassImage.Source = new BitmapImage(new Uri("eye_visible.png", UriKind.Relative));

                VisibilePasswordLabel.Visibility = Visibility.Visible;
                HiddenPasswordLabel.Visibility = Visibility.Hidden;
            }
            else
            {
                PassImage.Source = new BitmapImage(new Uri("eye_hidden.png", UriKind.Relative));

                VisibilePasswordLabel.Visibility = Visibility.Hidden;
                HiddenPasswordLabel.Visibility = Visibility.Visible;
            }
        }
    }
}
